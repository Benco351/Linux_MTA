#ifndef Q1_H
#define Q1_H
  #include "Utilities.h"

  void printFlightsToAirport(char* airportName);
  void printFlightsData(FlightData object);
#endif
