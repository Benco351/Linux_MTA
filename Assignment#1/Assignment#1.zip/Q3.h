#ifndef Q3_H
#define Q3_H
  #include "Utilities.h"

  void findAirCrafts(FILE* f, char** aircrafts, int nofAirCrafts);
  void printQ3(FlightData FD);
#endif
