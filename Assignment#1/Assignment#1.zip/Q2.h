#ifndef Q2_H
#define Q2_H
  #include "Utilities.h"

  void printAirportSchedule(char* airportName);
  int compareFlights(const void* a, const void* b);
  void printFullSchedule(FlightData object);
#endif
